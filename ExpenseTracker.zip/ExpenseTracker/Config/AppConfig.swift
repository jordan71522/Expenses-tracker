import Foundation

enum AppConfig {
    static let appCenterSecret = "ec5cfc1a-bb18-478a-9bdd-25a39335015d"
}
